#include <bits/huge_val.h>

#define	NAN			HUGE_VAL
