Direct questions to:
  Charles Moad - cmoad@indiana.edu

Contents:
  Static dependencies for building mpl for win32 using 
  Visual Studio.
  Extract to the matplotlib source folder.

Note:
  The point behind this build is to allow for compilation
  of the wxpython extension.  Mingw cannot link against the
  libraries that are distributed by wxpython since they are
  built with VS.  It does not recognize the mangling of the
  C++ symbols.
  
  This has not yet been tested, but should work with python2.3.
  
Requirement:
  Visual Studio 7.1 (2003) is needed for python 2.4.
  Python 2.4 was built with this and VS8 will NOT work.
  Similarly python 2.3 need Visual Studio 6.
  A free (but untested) alternative is to use MS's free compiler.
  More info here: http://www.vrplumber.com/programming/mstoolkit/

Instructions:
  - This build makes similar assumption to the mingw build.
  - You should install the win32-unicode version of wxPython.
  - In order to build gtk, pygtk must be installed.  Also the
  gtk-win32 development and runtime environment should be
  installed to C:\GTK .  You can download them from
  http://gladewin32.sourceforge.net/
  - There is not an environment script like the mingw build
  - You're ready to build:
     > python setup.py build bdist_wininst
