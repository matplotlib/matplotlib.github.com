/////////////////////////////////////////////////////////////////////////////
// Name:        wx/dcps.h
// Purpose:     wxPostScriptDC base header
// Author:      Julian Smart
// Modified by:
// Created:
// Copyright:   (c) Julian Smart
// RCS-ID:      $Id: dcps.h,v 1.2 2005/05/04 18:51:56 JS Exp $
// Licence:     wxWindows Licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_DCPS_H_BASE_
#define _WX_DCPS_H_BASE_

#include "wx/generic/dcpsg.h"

#endif

